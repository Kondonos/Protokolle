#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/types.h>
#include <unistd.h>
#include <wait.h>

#define SHMSZ 8

void lockersem(int);
void unlocksem(int);

union semun {
	int val;
	struct semid_ds *buf;
	ushort *array;
};

int main() {
	pid_t pid[10];
	int i, j;
	key_t key_mem = 999;
	int shmid;
	union semun arg;

	if ((shmid = shmget(key_mem, SHMSZ, IPC_CREAT | 0666)) < 0) {
		perror("shmget");
		exit(1);
	}

	unsigned int *shm_parent;
	if ((shm_parent = shmat(shmid, NULL, 0)) == (unsigned int *) -1) {
		perror("shmat parent");
		exit(1);
	}

	key_t key_sem;
	int semid;
	if ((semid = semget(key_sem, 1, 0666 | IPC_CREAT)) == -1) {
		perror("semget parent");
		exit(0);

	}
	arg.val = 1;
	if (semctl(semid, 0, SETVAL, arg) == -1) {
		perror("semctl parent");
		exit(1);
	}

	*shm_parent = 0;

	for (i = 0; i < 10; i++) {
		pid[i] = fork();
		if (pid[i] < 0)
			perror("Fehler beim forken");
		else if (pid[i] == 0) {
			unsigned int *shm;
			unsigned int number;
			if ((shm = shmat(shmid, NULL, 0)) == (unsigned int *) -1) {
				perror("shmat im child");
				exit(1);

			}

			//printf("%d\n", *shm);
			for (j = 0; j < 100000; j++) {
				lockersem(semid);
				number = *shm;
				number++;
				*shm = number;
				unlocksem(semid);
			}
			exit(0);
		}
	}
	for (i = 0; i < 10; ++i) {
		int status;
		while (-1 == waitpid(pid[i], &status, 0))
			;
		if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
			printf("Process %d failed", i);
			exit(1);

		}

	}

	printf("Ausgabe: Aufgabe 4: %u\n", *shm_parent);
	return 0;

}

void unlocksem(int semID) {
	struct sembuf sb = { 0, 1, 0 };
	if (semop(semID, &sb, 1) == -1)
		perror("semop Error");

}

void lockersem(int semID) {
	struct sembuf sb = { 0, -1, 0 };
	if (semop(semID, &sb, 1) == -1)
		perror("semop ERROR");
}

