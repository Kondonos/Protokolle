/*
 * sharedmemory.c
 *
 *  Created on: 22.05.2016
 *      Author: max
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>

int ism=0;

int main(int argc, char **argv) {
	int* shmptr=&ism;
	int i,j,number,status;
	for(i=0;i<10;i++){
		switch(fork()){
		case -1:
			puts("fork fehler");
			return 1;
			break;
		case 0:
			for (j = 0; j < 10000; j++) {
				number=*shmptr;
				number++;
				shmptr=&number;
			}
			printf("child %i. %i\n",i+1,j);
			return 0;
			break;
		default:
			waitpid(-1,&status,0);
			break;
		}
	}
	if(i==10){

		printf("%i\n",number);
	}
}

