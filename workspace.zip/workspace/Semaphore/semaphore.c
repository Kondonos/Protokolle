#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <semaphore.h>
#include <fcntl.h>

void lockersem(sem_t*);
void unlocksem(sem_t*);


int main(int argc, char **argv) {
	int i;
	key_t shmkey;
	int shmid;
	sem_t *sem;
	pid_t pid;
	int *p;
	unsigned int n=10;
	unsigned int value;

	shmkey=ftok("/dev/null",5);
	shmid=shmget(shmkey,sizeof(int),0666|IPC_CREAT);
	if(shmid<0){
		perror("shmget\n");
		exit(1);
	}
	p=(int*)shmat(shmid,NULL,0);
	*p=0;
	value=0;
	sem=sem_open("pSem",O_CREAT|O_EXCL,0666,value);
	sem_unlink("pSem");
	unlocksem(sem);

	for(i=0;i<n;i++){
		pid=fork();
		if(pid<0){
			perror("fork\n");
		}else if(pid==0){
			break;
		}
	}
	if(pid!=0){
		while((pid=waitpid(-1,NULL,0))){
			if(errno==ECHILD)
				break;
		}
		lockersem(sem);
		printf("%i\n",*p);
		unlocksem(sem);
		shmdt(p);
		shmctl(shmid,IPC_RMID,0);
		sem_destroy(sem);
		return 0;
	}else{
		for(i=0;i<10000;i++){
			printf("wait lock %i\n",getpid());
			lockersem(sem);
			(*p)++;
			unlocksem(sem);
		}
		return 0;
	}

}

void lockersem(sem_t* sem){
	sem_wait(sem);
}
void unlocksem(sem_t* sem){
	sem_post(sem);
}

