/*
 * sharedmemory.c
 *
 *  Created on: 22.05.2016
 *      Author: max
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <limits.h>

int ism=0;

int main(int argc, char **argv) {
	int shID;
	int* shptr;
	int i,j,number,status;
	int pids[10];
	shID=shmget(2404,sizeof(int),IPC_CREAT|0666);
	if(shID>=0){
		shptr=shmat(shID,0,0);
		if(shptr==(int*)-1){
			perror("shmat");
			return 1;
		}else{
			*shptr=ism;
			shmdt(shptr);
		}
	}else {
		perror("shmget");
	}
	for(i=0;i<10;i++){
		switch (pids[i]=fork()) {
			case -1:
				perror("fork");
				break;
			case 0:
				printf("%i. startet\n",i+1);
				for(j=0;j<10000;j++){
					shptr=shmat(shID,0,0);
					if(shptr==NULL){
						perror("shmat");
					}
					number=*shptr;
					number++;
					*shptr=number;
					shmdt(shptr);
				}
				printf("%i. fin\n",i+1);
				return 0;
				break;
			default:
				break;
		}
	}
	if(i==10){
		for(i=0;i<10;i++)
			waitpid(pids[i],&status,0);
		shptr=shmat(shID,0,0);
		ism=*shptr;
		printf("%i\n",ism);
		shmdt(shptr);
	}
	shmctl(shID,IPC_RMID,0);
	return 0;
}


