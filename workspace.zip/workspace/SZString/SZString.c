/*
 * SZString.c
 *
 *  Created on: 22.05.2016
 *      Author: max
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/unistd.h>
#include <limits.h>
#include <string.h>


#define BUFFER 512

void child(int*,int);

int main(int argc, char** arg) {
	int count, fd[2], pid, i,len;
	char* text;
	char* pattern;
	char* com;
	if (argc < 3) {
		puts("Zu wenige Argumente!");
		return 1;
	}
	text = arg[1];
	pattern = arg[2];
	printf("Es ist %s in %s zu Suchen!\n", pattern, text);
	len=strlen(text) + strlen(pattern) + 1;
	pipe(fd);
	switch (pid = fork()) {
	case -1:
		puts("fork() fehlgeschlagen!");
		return 1;
		break;
	case 0:
		child(fd,len);
		break;
	default:
		len=strlen(text) + strlen(pattern) + 1;
		com = malloc(len);
		for (i = 0; i < len; i++) {
			if(i<strlen(text)){
				com[i] = text[i];
			}else if(i==strlen(text)){
				com[i]=';';
			}else if(i>strlen(text)){
				com[i]=pattern[i-strlen(text)-1];
			}
		}
		printf("Übergebe Kind mit der pid %d die Argumente: %s %s\n", pid, text, pattern);
		write(fd[1],com, strlen(com));
		sleep(1);
		read(fd[0],&count,sizeof(int));
		printf("Das Kind fand das Wort %s %i mal in %s",pattern,count,text);
	}

	return 0;
}

void child(int* fd,int len){
	int count, line;
	char *com=malloc(len), *text, *pattern, readbuffer[BUFFER],dim[]=";";
	FILE *file;
	read(fd[0],com,len);

	text=strtok(com,dim);
	pattern=strtok(NULL,dim);
	printf("Ich (%d) habe folgende Parameter erhalten: %s %s\n",getpid(), text,pattern);
	file=fopen(text,"r+");
	if(file==NULL){
		printf("%s konnte nicht geöffnet werden\n",text);
		exit(1);
	}
	count=0;
	line =1;
	while(fgets(readbuffer,BUFFER,file)!=NULL){
		if(strstr(readbuffer,pattern)!=NULL){
			printf("Treffer in Zeile %i\n",line);
			count++;
		}
		line++;
	}
	write(fd[1],&count,sizeof(int));
}
